import React, { Component } from 'react';
import { AppRegistry, Text, View, StyleSheet, Image, TextInput, ImageBackground, TouchableHighlight, Alert, Dimensions, ScrollView } from 'react-native';
import Constants from 'expo-constants';

let deviceHeight = Dimensions.get('window').height; //532
let deviceWidth = Dimensions.get('window').width; //299

export default class App extends Component {
     state = {
        stockValue: null,
        currentTime: null,
        projectedStockValue: null,
        projectedTime: null,
        highValue: null,
        lowValue: null,
        stocksPage: 'none',
        homePage: 'block',
        rivalStockValues: {},
    };

    componentDidMount() {
        const stockValue = this.generateRandomStockValue(100);
        const currentTime = this.getCurrentTime();
        this.generateRivalStockValues();
        // Calculate the projected stock value in 4 hours
        const projectedStockValue = (parseFloat(stockValue) + (Math.random() * 20 - 10)).toFixed(2);

        // Get the current time and add 4 hours to it
        const currentTimeObject = new Date();
        currentTimeObject.setHours(currentTimeObject.getHours() + 4);
        const projectedTime = `${currentTimeObject.getHours()}:${(currentTimeObject.getMinutes() < 10 ? '0' : '')}${currentTimeObject.getMinutes()} ${currentTimeObject.getHours() >= 12 ? 'PM' : 'AM'}`;

        // Generate high and low values based on the current stock value
        const { highValue, lowValue } = this.generateHighLow(stockValue);

        this.setState({
            stockValue,
            currentTime,
            projectedStockValue,
            projectedTime,
            highValue,
            lowValue,
        });
    }
   
    generatePercentageChange = () => {
    return (Math.random() * 10 - 5).toFixed(2); // Random value between -5% and 5%
    };
   
   
    generateRivalStockValues = () => {
    const rivalStockValues = {
      Samsung: 60000, // Example base value for Samsung
      Microsoft: 400,
      NVIDIA: 800,
      Amazon: 170,
    };

    Object.keys(rivalStockValues).forEach((rival) => {
      const baseValue = rivalStockValues[rival];
      const percentageChange = parseFloat(this.generatePercentageChange());
      const newValue = (baseValue * (1 + percentageChange / 100)).toFixed(2);
      rivalStockValues[rival] = { value: newValue, percentageChange };
    });

    this.setState({ rivalStockValues });
    };
   
   
    generateRandomStockValue(previousValue) {
    // Generate a random deviation between -5 and 5
    const deviation = (Math.random() * 10) - 5;
   
    // Calculate the new value based on the previous value and deviation
    const newValue = parseFloat(previousValue) + deviation;
   
    // Return the new value rounded to two decimal places
    return newValue.toFixed(2);
    };


    getCurrentTime() {
            const currentDate = new Date();
            let hours = currentDate.getHours();
            const minutes = currentDate.getMinutes();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // the hour '0' should be '12'
            const formattedTime = `${hours}:${minutes < 10 ? '0' : ''}${minutes} ${ampm}`;
            return formattedTime;
        }
       
    getCurrentDateTime() {
            const currentDate = new Date();
            const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            const dayOfWeek = days[currentDate.getDay()];
            const dayOfMonth = currentDate.getDate();
            const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            const month = months[currentDate.getMonth()];
            const year = currentDate.getFullYear();
            let hours = currentDate.getHours();
            const minutes = currentDate.getMinutes();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // the hour '0' should be '12'
            const formattedTime = `${hours}:${minutes < 10 ? '0' : ''}${minutes} ${ampm}`;
            return `${dayOfWeek}, ${month} ${dayOfMonth}, ${year} - ${formattedTime}`;
        }
   
    handleRefresh = () => {
        const newStockValue = this.generateRandomStockValue(this.state.stockValue);
        this.setState({ stockValue: newStockValue });
       
        this.generateRivalStockValues();
        }
       
    generateHighLow(currentValue) {
        // Define the percentage deviation for high and low values
        const deviationPercentage = 5; // You can adjust this percentage as needed

        // Calculate the deviation amount based on the current value
        const deviationAmount = (currentValue * deviationPercentage) / 100;

        // Calculate the high and low values
        const highValue = (parseFloat(currentValue) + deviationAmount).toFixed(2);
        const lowValue = (parseFloat(currentValue) - deviationAmount).toFixed(2);

        return { highValue, lowValue };
    };
   
    switchPage = () => this.setState(state => ({
        homePage: 'none',
        stocksPage: 'block',
    }));
   
    switchPage2 = () => this.setState(state => ({
        homePage: 'block',
        stocksPage: 'none',
    }))


   
   
   
    render() {
       
       
       
        return (
            <View style={styles.container}>
               <View style={{ display: this.state.homePage }}>
               
                    <View style={{alignItems: 'center', justifyContent: 'center', height: deviceHeight, textAlign: 'center',}}>
                           
                           
                           
                           
                            <Text style={{fontWeight: 'bold', fontSize: deviceHeight/15, margin: 10, }}>
                            Apple Current & Projected Stocks
                            </Text>
                            <Image
                                source={{ uri: 'https://cdn-icons-png.flaticon.com/512/6410/6410570.png' }}
                                style={{ height: 200, width: 200 }}
                            />
                            <TouchableHighlight style={styles.navBarButton}
                                    onPress={() => this.switchPage()}
                                    >
                                        <Text style={styles.navBarButtonText}>
                                            Apple Stocks
                                        </Text>
                            </TouchableHighlight>
                           
                           
                           
                           
                           
                    </View>
                           
                </View>
           
            <View style={{ display: this.state.stocksPage }}>
                <ScrollView style={styles.container}>
                   
                    <View style={styles.locationContainer}>
                       
                        <Image
                            source={{ uri: 'https://cdn-icons-png.flaticon.com/512/25/25345.png' }}
                            style={{ height: deviceHeight/25, width: deviceHeight/25 }}
                        />
                        <Text style={{fontWeight: 'bold', fontSize: deviceHeight/25, marginLeft: 15,}}>
                                Apple Inc.
                            </Text>
                    </View>
               
                   
                    <View style={styles.todayContainer}>
                       
                        <View style={styles.leftToday}>
                            <Text style={{fontWeight: 'bold', fontSize: deviceHeight/44, marginLeft: 15, marginTop: 10}}>
                                Stocks
                            </Text>
                            <Text style={{fontWeight: 'bold', fontSize: deviceHeight/18, marginLeft: 15, marginTop: 10}}>
                                {this.state.currentTime}
                            </Text>
                            <Text style={{ fontSize: deviceHeight/44, marginLeft: 15, marginTop: 10}}>
                            High: ${this.state.highValue} Low: ${this.state.lowValue}
                        </Text>
                        </View>
                        <View style={styles.rightToday}>
                       
                            <Text style={{fontWeight: 'bold', fontSize: deviceHeight/36 /* ~18 */, marginRight: 15, marginTop: 10}}>
                                {this.getCurrentDateTime()}
                            </Text>
                            <Text style={{fontWeight: 'bold', fontSize: deviceHeight/35, marginRight: 15, marginTop: 10}}>
                                Projected: ${this.state.projectedStockValue} @ {this.state.projectedTime}
                            </Text>
                        </View>
                    </View>
                   
                   
                           
                   
                        <View style={styles.hourlyContainer}>
                           
                           <Text style={{fontWeight: 'bold', fontSize: deviceHeight/29.5 /* ~18 */, marginLeft: 10, marginTop: 10}}>
                                Stocks today
                            </Text>
                            <View style={styles.hourlyBox}>
                               
                                <View style={styles.hourWeather}>
                               
                                    <Text style={{fontWeight: 'bold', fontSize: deviceHeight/38}}>
                                    {this.state.stockValue} USD
                                    </Text>
                                    <Image
                                        source={{ uri: 'https://codehs.com/uploads/a59ce442200933fca193dab2d8f36b9e' }}
                                        style={{ height: 50, width: deviceWidth/2 }}
                                    />
                                    <Text style={styles.paragraph}>
                                    Now
                                    </Text>
                                   
                                   
                                 
                                   
                                </View>
                               
                               
                               
                                <TouchableHighlight style={styles.navBarButton}
                                        onPress={() => this.handleRefresh()}
                                        >
                                            <Text style={styles.navBarButtonText}>
                                                Refresh
                                            </Text>
                                </TouchableHighlight>
                           
                           
                            </View>
                             
                        </View>
                       
   
                        <View style={styles.tenDayContainer}>
                            <Text style={{fontWeight: 'bold', fontSize: deviceHeight/29.5 /* ~18 */, marginLeft: 10, marginTop: 10}}>
                                Rival Situation
                            </Text>
                           
                           
                            <View style={{height: deviceHeight/3, width: deviceWidth, backgroundColor: 'white', flexDirection: 'row', }}>
                               
                                <View style={{ width: deviceWidth / 2 }}>
                                  {Object.keys(this.state.rivalStockValues).map((rival) => (
                                    <View key={rival} style={styles.rivalContainer}>
                                      <Text style={styles.rivalName}>{rival}</Text>
                                      <View style={styles.rivalValueBox}>
                                        <Text style={[styles.stockValue, { color: this.state.rivalStockValues[rival].percentageChange >= 0 ? 'green' : 'red' }]}>
                                          {this.state.rivalStockValues[rival].value} ({this.state.rivalStockValues[rival].percentageChange}%)
                                        </Text>
                                      </View>
                                    </View>
                                  ))}
                                </View>
                            </View>
                        </View>
                       
                        <TouchableHighlight style={styles.navBarButton}
                                    onPress={() => this.switchPage2()}
                                    >
                                        <Text style={styles.navBarButtonText}>
                                            Home
                                        </Text>
                            </TouchableHighlight>
                </ScrollView>
           
            </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        height: deviceHeight,
        width: deviceWidth,
        backgroundColor: 'Grey',
    },
    todayContainer: {
        height: deviceHeight/5,
        width: deviceWidth,
        //justifyContent: 'center',
        flexDirection: 'row',
        alignItems: 'center',
        //backgroundColor: 'red',
    },
    locationContainer: {
        height: deviceHeight/12,
        width: deviceWidth,
        justifyContent: 'center',
        alignItems: 'center',
        //backgroundColor: 'lightGray'
        flexDirection: 'row',
    },
    leftToday: {
        height: deviceHeight/5,
        width: deviceWidth/2,
        //justifyContent: 'center',
        //backgroundColor: 'red',
    },
    rightToday: {
        height: deviceHeight/5,
        width: deviceWidth/2,
        //justifyContent: 'center',
        alignItems: 'flex-end',
       
        //backgroundColor: 'red',
       
    },
    hourlyContainer: {
        height: deviceHeight/4,
        width: deviceWidth,
        //justifyContent: 'center',
       
        backgroundColor: 'White',
    },
    hourlyBox: {
        height: deviceHeight/6,
        backgroundColor: 'white',
        borderRadius: 8,
        margin: 10,
        flexDirection: 'row',
    },
    hourWeather: {
        alignItems: 'center',
        margin: 2,
    },
    dayForecast: {
        flexDirection: 'row',
        alignItems: 'center',
        width: deviceWidth/1.09,
        justifyContent: 'center',
        backgroundColor: 'white',
        margin: 10,
        borderRadius: 10,
        textAlign: 'flex-start',
    },
    tenDayContainer: {
        backgroundColor: 'grey',
    },
    currentBoxes: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    whiteBox: {
        height: deviceHeight/4,
        width: deviceWidth/2.18,
        borderRadius: 15,
        backgroundColor: 'white',
        margin: 3
    },
    navBarButton: {
        height: deviceHeight/15,
        width: deviceWidth/3,
        borderWidth: 2,
        borderColor: 'black',
        backgroundColor: 'white',
        textAlign: 'center',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
        margin: 3,
    },
    navBarButtonText: {
        fontSize: 15,
        fontWeight: 'bold',
       
    },
    title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  rivalContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  rivalName: {
    marginRight: 10,
    fontSize: 20,
    fontWeight: 'bold',
  },
  stockValue: {
    fontSize: 16,
  },
  rivalValueBox: {
  borderWidth: 1,
  borderColor: 'black',
  borderRadius: 5,
  padding: 5,
},
});